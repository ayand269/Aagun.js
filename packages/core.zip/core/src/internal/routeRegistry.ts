export const routeRegistry: {
    path: string;
    method: string;
    controller: any;
    methodName: string;
}[] = [];
